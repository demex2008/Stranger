#!/usr/bin/env python
# -*- coding: utf-8 -*-

__version__ = '0.6.0'
__author__ = 'Ellison Leão'
__license__ = 'MIT'

# flake8: noqa
from .shorteners import Shortener, Shorteners
