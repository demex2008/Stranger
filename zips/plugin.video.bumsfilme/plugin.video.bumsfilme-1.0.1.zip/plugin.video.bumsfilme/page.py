#!/usr/bin/python
# -*- coding: utf-8 -*-
import xbmc,xbmcgui,xbmcplugin,xbmcaddon,urllib,sys,os,re,request,player

_base_url_ = 'https://bumsfilme.com/'

def de_en_code_path(path):
    if sys.platform.startswith('win'):
        return xbmc.translatePath( path ).decode('utf-8')
    else:
        return xbmc.translatePath( path ).encode('utf-8')

_addon_ =  xbmcaddon.Addon(id='plugin.video.bumsfilme')
_addon_root_ = de_en_code_path(_addon_.getAddonInfo('path'))
_images_path_ = os.path.join(_addon_root_,'resources','images')

def clean_title(s):
    return s.replace('&amp;','und')

def addDir(name,url,mode,iconimage):
    u=sys.argv[0]+'?url='+urllib.quote_plus(url)+'&mode='+str(mode)+'&name='+urllib.quote_plus(name)+'&iconimage='+urllib.quote_plus(iconimage)
    liz=xbmcgui.ListItem(name, iconImage='DefaultFolder.png', thumbnailImage=iconimage)
    liz.setInfo( type='video', infoLabels={ 'Title': name } )
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)

def regex_next_page(content):
    match = re.search('var pbd_alp[\s\S]*?nextLink":"(.*?)"', content,re.DOTALL)
    if match:return match.group(1).replace('\\','')
    else:return ''

def regex_s1(content):
    for url,title,img in re.findall('<article id="post[\s\S]*?href="(.*?)"[\s\S]*?title="(.*?)"[\s\S]*?src="(.*?)"',content,re.DOTALL):
        addDir(clean_title(title),url,1,img)
    addDir('[COLOR blue]Schlagwortsuche ?[/COLOR]','',4,os.path.join(_images_path_,'search.png'))

def regex_s2(content,next_page_url):
    for url,title,img,length in re.findall('<article id="post[\s\S]*?href="(.*?)"[\s\S]*?title="(.*?)"[\s\S]*?src="(.*?)"[\s\S]*?<i class="fa fa-clock-o"><\/i>(.*?)<\/span>',content,re.DOTALL):
        addDir(clean_title(title) + ' | ' + length.strip(),url,2,img)
    addDir('[COLOR blue]Schlagwortsuche ?[/COLOR]','',4,os.path.join(_images_path_,'search.png'))
    if not next_page_url == '':
        addDir('[COLOR blue]Mehr Bumsfilme >>>[/COLOR]',next_page_url,5,os.path.join(_images_path_,'next.png'))
    addDir('[COLOR blue]Zurück zur Startseite <<<[/COLOR]',next_page_url,6,os.path.join(_images_path_,'back.png'))

def regex_iframe(content):
    match = re.search('<iframe src="(.*?)"', content,re.DOTALL)
    if match:return match.group(1)
    else:return ''

def regex_play_url(name,content,img):
    for url,title,res in re.findall('<source src="(.*?)"[\s\S]*?label="(.*?)"[\s\S]*?res="(.*?)"',content,re.DOTALL):
        addDir(name + ' | ' + title + ' - ' + res,url,3,img)

def get_params():
    param=[]
    paramstring=sys.argv[2]
    if len(paramstring)>=2:
        params=sys.argv[2]
        cleanedparams=params.replace('?','')
        if (params[len(params)-1]=='/'):
            params=params[0:len(params)-2]
        pairsofparams=cleanedparams.split('&')
        param={}
        for i in range(len(pairsofparams)):
            splitparams={}
            splitparams=pairsofparams[i].split('=')
            if (len(splitparams))==2:
                param[splitparams[0]]=splitparams[1]                         
        return param		
params=get_params()

url=None
name=None
mode=None
iconimage=None

try:
    url=urllib.unquote_plus(params["url"])
except:
    pass
try:
    name=urllib.unquote_plus(params["name"])
except:
    pass
try:
    iconimage=urllib.unquote_plus(params["iconimage"])
except:
    pass
try:        
    mode=int(params["mode"])
except:
    pass

if mode == None: 
    content = request.requesthandler(_base_url_ + 'kategorien')	
    regex_s1(content)

if mode == 1:
    content = request.requesthandler(url)
    next_page_url = regex_next_page(content)
    regex_s2(content,next_page_url)

if mode == 2:
    content = request.requesthandler(url)
    iframe_url = regex_iframe(content)
    if not iframe_url == '':
        content = request.requesthandler(iframe_url)
        regex_play_url(name,content,iconimage)

if mode == 3:
    player.play(url, name, iconimage)

if mode == 4:
    keyboard = xbmc.Keyboard()
    keyboard.setHeading('Schlagwortsuche')
    keyboard.setDefault('')
    keyboard.doModal()
    if keyboard.isConfirmed() and keyboard.getText():
        content = request.requesthandler(_base_url_ + '?s=' + keyboard.getText())	
        next_page_url = regex_next_page(content)
        regex_s2(content,next_page_url)
    else:sys.exit(0)

if mode == 5:
    content = request.requesthandler(url)
    next_page_url = regex_next_page(content)
    regex_s2(content,next_page_url)

if mode == 6:
    content = request.requesthandler(_base_url_ + 'kategorien')	
    regex_s1(content)

xbmcplugin.endOfDirectory(int(sys.argv[1]))