#!/usr/bin/python
# -*- coding: utf-8 -*-
import xbmc,xbmcgui,xbmcplugin,xbmcaddon,urllib,sys,os,io,re,math,time,datetime

BASE_URL ='https://mp3co.biz'

def fix_encoding(path):
    if sys.platform.startswith('win'):return unicode(path,'utf8')
    else:return unicode(path,'utf8').encode('latin-1')

_addon_ =  xbmcaddon.Addon()
_addon_id_ = _addon_.getAddonInfo('id')
_addon_path_ = fix_encoding(_addon_.getAddonInfo('path'))

_playlist_ = xbmc.PlayList(0)
xbmcplugin.setContent(int(sys.argv[1]),'songs')

sys.path.append(os.path.join(_addon_path_,'resources','lib'))
import requests

def get_request(url,headers_dict=None):
    reg = requests.get(url,headers=headers_dict)
    content = reg.content
    reg.close()
    return content

def add_item(array_dict,is_folder=True,IsPlayable=False,load_playlist=False,context_menu=False):

    index = 0
    if load_playlist == True and len(_playlist_) > 0:_playlist_.clear()

    for dict in array_dict:

        listitem = xbmcgui.ListItem(label=dict['title'],iconImage='DefaultFolder.png',thumbnailImage=dict['image'],path=dict['url'])
        listitem.setInfo(type='audio',infoLabels={'Title':dict['title']})
        listitem.setProperty('fanart_image',dict['image'])

        if is_folder == True:url=sys.argv[0]+'?title='+urllib.quote_plus(dict['title'])+'&url='+urllib.quote_plus(dict['url'])+'&image='+urllib.quote_plus(dict['image'])+'&imode='+str(dict['imode'])
        if is_folder == False:url=dict['url']

        if IsPlayable==True:listitem.setProperty('IsPlayable','true')
        if IsPlayable==False:listitem.setProperty('IsPlayable','false')

        if context_menu == True:
            com = [('[COLOR blue]DOWNLOAD SELECT ITEM[/COLOR]','Xbmc.RunPlugin(%s)' % (sys.argv[0]+'?cmode=1'+'&title='+urllib.quote_plus(dict['title'])+'&url='+urllib.quote_plus(dict['url'])))]
            listitem.addContextMenuItems(items=com,replaceItems=True)

        if load_playlist == True:_playlist_.add(url=dict['url'],listitem=listitem,index=index);index += 1
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=listitem,isFolder=is_folder,totalItems=len(array_dict))

def regex_next_page(content):
    match = re.compile('<div class="paging cf">[\s\S]*?<a class="active">(.*?)<\/a><a href="(.*?)">(.*?)<\/a>[\s\S]*?<\/div></section>', re.DOTALL).search(content)
    if match :
        add_item([{'title':'[COLOR blue]Back to Start [/COLOR]','url':'update','image':os.path.join(_addon_path_,'start.png'),'imode':None}],is_folder=True,IsPlayable=False,load_playlist=False,context_menu=False)
        add_item([{'title':'[COLOR blue]Next Page [/COLOR]' + match.group(1) + '[COLOR blue] >>> [/COLOR]' + match.group(3),'url':BASE_URL + match.group(2),'image':os.path.join(_addon_path_,'next.png'),'imode':1}],is_folder=True,IsPlayable=False,load_playlist=False,context_menu=False)

def regex_genres_bar(content):
    array_dict_list=[]
    match = re.compile('<div class="genres-bar">[\s\S]*?<\/div>', re.DOTALL).search(content)
    if match :
        for url,title in re.compile('<a href="(.*?)">(.*?)<\/a>', re.DOTALL).findall(match.group(0)):
            array_dict_list.append({'title':title.strip(),'url':BASE_URL + url,'image':os.path.join(_addon_path_,'folder.png'),'imode':1})

    array_dict_list.append({'title':'[COLOR blue]Song Search ?[/COLOR]','url':'','image':os.path.join(_addon_path_,'search.png'),'imode':3})
    add_item(array_dict_list,is_folder=True,IsPlayable=False,load_playlist=False,context_menu=False)

def regex_online_radio_class_side(content):
    array_dict_list=[]
    match = re.compile('<div class="side">[\s\S]*?<\/div>', re.DOTALL).search(content)
    if match :
        for url,title in re.compile('<a href="(.*?)">(.*?)<\/a>', re.DOTALL).findall(match.group(0)):
            array_dict_list.append({'title':title.strip(),'url':BASE_URL + url,'image':os.path.join(_addon_path_,'folder.png'),'imode':2})

        add_item(array_dict_list,is_folder=True,IsPlayable=False,load_playlist=False,context_menu=False)

def regex_online_radio_class_list(content):
    array_dict_list=[]
    match = re.compile('<div class="sList">[\s\S]*?<\/a>\n<\/div>', re.DOTALL).search(content)
    if match :
        for url,img,title in re.compile('href="(.*?)"[\s\S]*?src="(.*?)"[\s\S]*?itemprop="name">(.*?)<\/div>', re.DOTALL).findall(match.group(0)):
            array_dict_list.append({'title':title.strip(),'url':url,'image':BASE_URL + img,'imode':0})

        add_item(array_dict_list,is_folder=False,IsPlayable=True,load_playlist=False,context_menu=False)
        add_item([{'title':'[COLOR blue]Back to Start [/COLOR]','url':'update','image':os.path.join(_addon_path_,'start.png'),'imode':None}],is_folder=True,IsPlayable=False,load_playlist=False,context_menu=False)

def regex_song_list(content):
    array_dict_list=[]
    match = re.compile('<table class="songs">[\s\S]*?<\/table>', re.DOTALL).search(content)
    if match :
        for url,artist,title,time in re.compile('play[\s\S]*?href="(.*?)"[\s\S]*?item artist[\s\S]*?>(.*?)<\/a>[\s\S]*?>(.*?)<\/a>[\s\S]*?<td class[\s\S]*?>(.*?)<\/td>', re.DOTALL).findall(match.group(0)):
            array_dict_list.append({'title':artist.strip() + ' ( ' + title.strip() + ' ) ' + time.strip(),'url':url,'image':os.path.join(_addon_path_,'mp3.png'),'imode':0})

        add_item(array_dict_list,is_folder=False,IsPlayable=True,load_playlist=True,context_menu=True)
        regex_next_page(content)

def search_keyboard():
    search_string = xbmcgui.Dialog().input('[COLOR blue]MP3CO.BIZ SEARCH[/COLOR]', type=xbmcgui.INPUT_ALPHANUM).strip()
    if not search_string == '':
        search_url = urllib.unquote_plus(BASE_URL + '/s/' + urllib.quote(search_string) + '/')
        content = get_request(search_url)
        regex_song_list(content)
    else:sys.exit(0)

def request_download_file(file_download_url,dir_save_path,headers_dict=None):

    dp = xbmcgui.DialogProgress()
    dp.create('[COLOR blue]MP3CO.BIZ ( MP3 ) DOWNLOADER[/COLOR]','Download file !','Please wait ...' )
    dp.update(0)

    total_size = int(0)
    downloaded = int(0)

    def convert_size(size):
	    if ( size == 0 ):return '0B'
	    units = (' B',' KB',' MB',' GB',' TB',' PB',' EB',' ZB',' YB' )
	    i = int( math.floor( math.log(size,1024)))
	    p = math.pow(1024,i)
	    size = "%.3f" % round((size / p ),3)
	    return '{}{}'.format(size,units[i])

    filename = file_download_url.split('/')[-1]
    file_save_path = os.path.join(dir_save_path,filename)
    req = requests.get(file_download_url,stream=True,headers=headers_dict)
    total_size = int(req.headers.get('content-length'))

    CHUNK = 1024 * 16
    start_time = time.time();xbmc.sleep(1)
    with io.open(file_save_path,'wb',buffering=CHUNK) as fi:
        while True:

            chunk = req.raw.read(CHUNK)
            if not chunk:break

            fi.write(chunk)
            downloaded +=len(chunk)

            percent = min(downloaded * 100 / total_size, 100)
            speed = (downloaded / ( time.time() - start_time))

            if speed > 0: remaining_sec = ((total_size - downloaded ) / speed)
            else: remaining_sec = 0

            s = 'Loaded: %s from %s - ( %s%% )'% (convert_size(downloaded),convert_size(total_size),str(percent))
            ss = 'Speed: %s/s' % (convert_size(speed))
            sss = 'Remaining time: %s' % datetime.timedelta(seconds=remaining_sec)
            dp.update(percent,s,ss,sss)

            if dp.iscanceled():
                req.close()
                fi.close()
                dp.close()
                break

    dp.update(100)
    req.close()
    fi.close()		
    dp.close()
    sys.exit(0)

def get_params():
    param=[]
    paramstring=sys.argv[2]
    if len(paramstring)>=2:
        params=sys.argv[2]
        cleanedparams=params.replace('?','')
        if (params[len(params)-1]=='/'):
            params=params[0:len(params)-2]
        pairsofparams=cleanedparams.split('&')
        param={}
        for i in range(len(pairsofparams)):
            splitparams={}
            splitparams=pairsofparams[i].split('=')
            if (len(splitparams))==2:
                param[splitparams[0]]=splitparams[1]                         
        return param		
params=get_params()

title=None
try:title=urllib.unquote_plus(params['title'])
except:pass
url=None
try:url=urllib.unquote_plus(params['url'])
except:pass
image=None
try:image=urllib.unquote_plus(params['image'])
except:pass
imode=None
try:imode=int(params['imode'])
except:pass
index=None
try:index=int(params['index'])
except:pass
cmode=None
try:cmode=int(params['cmode'])
except:pass

if imode == None and cmode == None:
    if url == 'update':xbmc.executebuiltin('XBMC.Container.Update(path,replace)')
    content = get_request(BASE_URL)			
    regex_genres_bar(content)

if imode == 1 and cmode == None and 'Online Radio' in title:
    content = get_request(url)			
    regex_online_radio_class_side(content)

if imode == 1 and cmode == None and not 'Online Radio' in title:
    content = get_request(url)
    regex_song_list(content)

if imode == 2 and cmode == None:
    content = get_request(url)	
    regex_online_radio_class_list(content)
	
if imode == 3 and cmode == None:
    search_keyboard()

if cmode == 1:
    download_path = _addon_.getSetting('download_path')
    if download_path == '' or not os.path.exists(download_path):xbmc.executebuiltin('Addon.OpenSettings('+ _addon_id_ +')');sys.exit(0)
    request_download_file(url,download_path)

xbmcplugin.endOfDirectory(handle=int(sys.argv[1]),succeeded=True,updateListing=False,cacheToDisc=False)